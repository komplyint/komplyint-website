PALVELUESITE / SUOMI
Ohjelmistokehitys, data ja IT-palvelut
Sovimme jokaisen toimeksiannon sisällöstä erikseen. Emme tarjoa oikeudellista neuvontaa, sertifiointia tai viranomaishyväksyntöjä.

SERVICE BROCHURE / ENGLISH
Software engineering, data and IT services
Every project has an agreed scope. We do not provide legal advice, certification or regulatory approval.

TJÄNSTEBROSCHYR / SVENSKA
Programutveckling, data och IT-tjänster
Vi kommer överens om varje uppdrags omfattning separat. Vi erbjuder inte juridisk rådgivning, certifiering eller myndighetsgodkännanden.

Komplyint Oy
info@komplyint.fi
https://www.komplyint.fi
